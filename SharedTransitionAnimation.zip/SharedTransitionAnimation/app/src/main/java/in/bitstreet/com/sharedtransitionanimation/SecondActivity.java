package in.bitstreet.com.sharedtransitionanimation;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {


    Button mBtnSignup;
    private TextView mBkTitle;
    private TextView mBkAuthor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        initView();
        /*Intent intent = getIntent();
        Book book = intent.getParcelableExtra("Book");

        mBkTitle.setText("Title:" + book.getTitle());
        mBkAuthor.setText("Author:" + book.getAuthor());*/
    }

    private void initView() {
        mBkTitle = (TextView) findViewById(R.id.input_email);
        mBkAuthor = (TextView) findViewById(R.id.input_password);
        mBtnSignup = (Button) findViewById(R.id.btn_signup);


    }

}
