package in.bitstreet.com.parcelablesample;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

public class Book implements Parcelable {
    // book basics
    private String title;
    private String author;

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Book createFromParcel(Parcel parcel) {
            return new Book(parcel);
        }

        public Book[] newArray(int size) {
            Log.e("sizefgbfbfgbfg",""+size);
            return new Book[size];
        }
    };

    public Book(Parcel parcel) {
        title = parcel.readString();
        author = parcel.readString();
    }



    // main constructor
    public Book(String title, String author) {
       this.title = title;
        this.author = author;
    }

    // getters
    public String getTitle() { return title; }
    public String getAuthor() { return author; }


    @Override
    public int describeContents() {
        return 0;
    }

    // write object values to parcel for storage
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(author);
    }

}
