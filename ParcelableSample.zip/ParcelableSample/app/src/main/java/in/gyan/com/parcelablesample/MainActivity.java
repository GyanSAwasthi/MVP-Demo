package in.gyan.penzebra.parcelablesample;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mBkTitle;
    private EditText mBkAuthor;
    private ImageView img;
    private Button mBtnSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        mBkTitle = (EditText) findViewById(R.id.input_email);

        mBkAuthor = (EditText) findViewById(R.id.input_password);
        img = (ImageView) findViewById(R.id.imgView);

        mBtnSignup = (Button) findViewById(R.id.btn_signup);
        mBtnSignup.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.input_email:
                break;
            case R.id.input_password:
                break;
            case R.id.btn_signup:
                Book book = new Book(mBkTitle.getText().toString(),
                        mBkAuthor.getText().toString());

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("Book", book);
                startActivity(intent);

              /*  Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                ActivityOptionsCompat options = ActivityOptionsCompat.
                        makeSceneTransitionAnimation(MainActivity.this,
                                img,
                                "simple_activity_transition");
                startActivity(intent, options.toBundle());*/
                break;
        }

        }
    }

