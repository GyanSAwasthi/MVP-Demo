package in.penzebra.gyan.com.mvpdesignpattern.interfacemvp;


import java.util.List;

public interface IResultView<T> {

    //onCreate
    void showResult(T listDO);

    //onMessage display
    void onDisplayMessage(String message);

    void showResultList(List<T> resultDOList);



    void displayErrorList(List<String> errorList);
   // void showResultUserInfo(T listDO);
}
