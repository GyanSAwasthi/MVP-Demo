package in.penzebra.gyan.com.mvpdesignpattern.interfacemvp;



public interface INetworkResult<T> {

    void onSuccess(T responseBody, int responseType);

    void onError(String message);


}
