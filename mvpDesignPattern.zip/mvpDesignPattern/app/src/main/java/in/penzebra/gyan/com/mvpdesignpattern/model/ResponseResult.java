package in.penzebra.gyan.com.mvpdesignpattern.model;

import com.google.gson.annotations.SerializedName;

public class ResponseResult {



    @SerializedName("success")
    public boolean success;
    @SerializedName("status")
    public int status;
    @SerializedName("message")
    public String message;
    @SerializedName("data")
    public DataBean data;

    public static class DataBean {


        @SerializedName("publicKey")
        public String publicKey;
        @SerializedName("privateKey")
        public String privateKey;
    }
}
