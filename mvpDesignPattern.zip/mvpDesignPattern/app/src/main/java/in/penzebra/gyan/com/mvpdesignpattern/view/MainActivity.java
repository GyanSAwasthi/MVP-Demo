package in.penzebra.gyan.com.mvpdesignpattern.view;

import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.format.Formatter;
import android.widget.Toast;

import com.google.gson.JsonObject;

import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import in.penzebra.gyan.com.mvpdesignpattern.R;
import in.penzebra.gyan.com.mvpdesignpattern.interfacemvp.IResultView;
import in.penzebra.gyan.com.mvpdesignpattern.model.ResponseResult;
import in.penzebra.gyan.com.mvpdesignpattern.presenter.AuthenticateImpl;

import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission_group.CAMERA;

public class MainActivity extends AppCompatActivity implements IResultView {
    TimeZone tz;
    Context context;
    public static final int RequestPermissionCode = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        if (!checkPermission()) {
            requestPermission();
        } else {
            callApi();
        }


    }

    private void callApi() {
        AuthenticateImpl authenticateImpl = new AuthenticateImpl(context, this);
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        String ipAddress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
        tz = TimeZone.getDefault();

        JsonObject params = new JsonObject();
        params.addProperty("deviceId", Settings.Secure.getString(this.getContentResolver(),
                Settings.Secure.ANDROID_ID));
        params.addProperty("model", android.os.Build.MODEL);
        params.addProperty("platform", "Android");
        params.addProperty("manufacturer", android.os.Build.MANUFACTURER);
        params.addProperty("version", android.os.Build.VERSION.RELEASE);
        params.addProperty("serial", android.os.Build.SERIAL);
        params.addProperty("imeiNo", getIMEI());
        params.addProperty("ip", ipAddress);
        params.addProperty("timeZone", tz.getDisplayName(false, TimeZone.SHORT));
        params.addProperty("timeZoneId", tz.getID());


       


        authenticateImpl.callLoginAPI(params);
    }

    public boolean checkPermission() {
        int permissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), READ_PHONE_STATE);
        return
                permissionResult == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(MainActivity.this, new String[]
                {

                        READ_PHONE_STATE, CAMERA
                }, RequestPermissionCode);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {

            case RequestPermissionCode:

                if (grantResults.length > 0) {

                    boolean ReadPhoneStatePermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                    if (ReadPhoneStatePermission) {

                        callApi();

                    }
                }

                break;
        }
    }

    @Override
    public void showResult(Object listDO) {
        String result = ((ResponseResult)listDO).message;
        Toast.makeText(this,result,Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onDisplayMessage(String message) {

    }

    @Override
    public void showResultList(List resultDOList) {

    }

    @Override
    public void displayErrorList(List errorList) {

    }

    public String getUUID(Context context) {

        final TelephonyManager tm = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);

        final String tmDevice, tmSerial, androidId;
        tmDevice = "" + tm.getDeviceId();
        tmSerial = "" + tm.getSimSerialNumber();
        androidId = "" + android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        UUID deviceUuid = new UUID(androidId.hashCode(), ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
        String deviceId = deviceUuid.toString();

        return deviceId;
    }

    private String getIMEI() {

        String IMEI = null;
        TelephonyManager tm = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        if (null != tm) {
            IMEI = tm.getDeviceId();
        }
        if (null == IMEI || 0 == IMEI.length()) {
            IMEI = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
        }


        return IMEI;
    }


}