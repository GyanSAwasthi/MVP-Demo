package in.penzebra.gyan.com.mvpdesignpattern.networkclient;

public class NetworkConstants {

    public interface RESPONSE_TYPE {

        int RETRIEVE_TYPE = 11;
        int DELETE_TYPE = 41;
    }
}
