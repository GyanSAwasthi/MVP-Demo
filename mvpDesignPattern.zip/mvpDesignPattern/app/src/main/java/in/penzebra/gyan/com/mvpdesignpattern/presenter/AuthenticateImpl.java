package in.penzebra.gyan.com.mvpdesignpattern.presenter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.google.gson.JsonObject;

import java.util.TimeZone;
import java.util.UUID;


import in.penzebra.gyan.com.mvpdesignpattern.interfacemvp.IEndPointUrl;
import in.penzebra.gyan.com.mvpdesignpattern.interfacemvp.INetworkResult;
import in.penzebra.gyan.com.mvpdesignpattern.interfacemvp.IResultView;
import in.penzebra.gyan.com.mvpdesignpattern.model.ResponseResult;
import in.penzebra.gyan.com.mvpdesignpattern.networkclient.NetworkClient;
import in.penzebra.gyan.com.mvpdesignpattern.networkclient.NetworkConstants;
import in.penzebra.gyan.com.mvpdesignpattern.networkclient.NetworkHandler;
import retrofit2.Call;

public class AuthenticateImpl implements INetworkResult {

    //private static final String TAG = AuthenticateImpl.class.getSimpleName();
    private IEndPointUrl endPointsAPI;
    private Context context;
    private NetworkHandler networkHandler;
    private IResultView iResultViewListener;

    public AuthenticateImpl(Context context, IResultView iResultView) {
        this.context = context;
        this.iResultViewListener = iResultView;
        endPointsAPI = NetworkClient.getClient().create(IEndPointUrl.class);
        networkHandler = new NetworkHandler(this);

    }

    //region API


    @SuppressWarnings("unchecked")
    public void callLoginAPI(JsonObject params) {

        Call authenticateResponseCall = endPointsAPI.getRegisterDevice(params);
        authenticateResponseCall.enqueue(networkHandler.EnqueueRequest(NetworkConstants.RESPONSE_TYPE.RETRIEVE_TYPE));


    }

    //endregion


    @SuppressWarnings("unchecked")
    @Override
    public void onSuccess(Object responseBody, int responseType) {

        ResponseResult authenticateModel = (ResponseResult) responseBody;
        Log.e("SUCCESS", "SUCCESS");

        switch (responseType) {

            case NetworkConstants.RESPONSE_TYPE.RETRIEVE_TYPE:
                iResultViewListener.showResult(authenticateModel);

                break;
        }
    }

    @Override
    public void onError(String message) {

        iResultViewListener.onDisplayMessage(message);
    }
}
