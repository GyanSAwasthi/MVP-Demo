package in.bitstreet.com.eventbusexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.greenrobot.eventbus.Subscribe;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
    @Override
    protected void onStart() {
        super.onStart();
        // Register this fragment to listen to event.
        GlobalBus.getBus().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        GlobalBus.getBus().unregister(this);
    }

    @Subscribe
    public void getMessage(Events.ActivityActivityMessage activityActivityMessage) {
        TextView messageView = (TextView) findViewById(R.id.tvsecond);
        messageView.setText(getString(R.string.message_received) + " " + activityActivityMessage.getMessage());

        Toast.makeText(getApplicationContext(), "second activity   " + activityActivityMessage.getMessage(),
                Toast.LENGTH_SHORT).show();
    }
}
