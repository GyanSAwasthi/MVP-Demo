package in.gyan.com.facebooklogin;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import in.bitstreet.com.facebooklogin.R;

public class LauncherActivity extends AppCompatActivity {
    JSONObject response, profile_pic_data, profile_pic_url;
    TextView user_name ,user_email;
    ImageView user_picture ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        Button Button = (Button) findViewById(R.id.btn);
         user_name = (TextView) findViewById(R.id.UserName);
         user_picture = (ImageView) findViewById(R.id.profilePic);
         user_email = (TextView) findViewById(R.id.email);

        Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LauncherActivity.this, MainActivity.class);

                startActivityForResult(intent,2);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 2) {

                String jsondata=data.getStringExtra("userProfile");
                try {
                    response = new JSONObject(jsondata);
                    user_email.setText(response.get("email").toString());
                    user_name.setText(response.get("name").toString());
                    profile_pic_data = new JSONObject(response.get("picture").toString());
                    profile_pic_url = new JSONObject(profile_pic_data.getString("data"));
                    Picasso.with(this).load(profile_pic_url.getString("url"))
                            .into(user_picture);

                } catch(Exception e){
                    e.printStackTrace();
                }

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
